class HelloWorld extends HTMLElement {
  constructor() {
    super();
    console.log("hello world");
  }
}
customElements.define( 'hello-world', HelloWorld );