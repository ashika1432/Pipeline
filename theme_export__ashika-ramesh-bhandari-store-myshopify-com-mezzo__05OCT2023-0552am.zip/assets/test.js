function toggleButton() {
  document.querySelector(".text-block-row").classList.toggle("d-none");
  document.querySelector("variant-block-section").classList.toggle("d-none");
}