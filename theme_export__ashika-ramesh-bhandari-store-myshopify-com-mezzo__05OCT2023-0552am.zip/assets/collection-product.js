//filtering
function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

class CollectionFilters extends HTMLElement {
  constructor() {
    super();

    this.sectionId = this.dataset.sectionId;
    this.form = this.querySelector("form");

    this.debouncedOnSubmit = debounce((event) => {
      this.onSubmitHandler(event);
    }, 500);

    this.form.addEventListener("input", this.debouncedOnSubmit.bind(this));
  }

  onSubmitHandler(event) {
    event.preventDefault();
    const sortFilterForms = document.querySelectorAll(
      "collection-filters form"
    );
    const forms = [];

    sortFilterForms.forEach((form) => {
      forms.push(this.createSearchParams(form));
    });

    const params = forms.join("&");

    this.renderPage(params);
    this.updateUrl(params);
  }

  createSearchParams(form) {
    const formData = new FormData(form);
    return new URLSearchParams(formData).toString();
  }

  renderPage(params) {
    const url = `${window.location.pathname}?section_id=${this.sectionId}&${params}`;
    fetch(url)
      .then((response) => response.text())
      .then((responseText) => {
        const html = new DOMParser().parseFromString(responseText, "text/html");
        document.getElementById("CollectionFlex").innerHTML =
          html.getElementById("CollectionFlex").innerHTML;
      });
  }

  updateUrl(params) {
    history.pushState(
      { params },
      "",
      `${window.location.pathname}${params && "?".concat(params)}`
    );
  }
}
//grid layout
customElements.define("collection-filters", CollectionFilters);

document.querySelectorAll(".layout-button").forEach(function (button) {
  button.addEventListener("click", function (evt) {
    evt.preventDefault();

    const layout = this.dataset.layout;
    const previousClass = document.querySelector("#ProductGrid").classList[2];
    const newClass = `grid--${layout}-col-desktop`;

    document
      .querySelector("#ProductGrid")
      .classList.replace(previousClass, newClass);
  });
});


//filter toggle
function toggleFilter() {
  document.querySelector("aside").classList.toggle("is-active");
}

document.querySelectorAll("#ToggleFilter").forEach(function (button) {
  button.addEventListener("click", function (evt) {
    evt.preventDefault();

    const collectionFilter = document.querySelector("#CollectionFilter");
    if (collectionFilter.style.display === "none") {
      collectionFilter.style.display = "block";
    } else {
      collectionFilter.style.display = "none";
    }
  });
});


