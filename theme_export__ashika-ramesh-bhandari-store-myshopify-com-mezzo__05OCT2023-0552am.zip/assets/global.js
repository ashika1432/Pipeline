document.querySelectorAll('[id^="Details-"] summary').forEach((summary) => {
  summary.setAttribute('role', 'button');
  summary.setAttribute('aria-expanded', summary.parentNode.hasAttribute('open'));

  if(summary.nextElementSibling.getAttribute('id')) {
    summary.setAttribute('aria-controls', summary.nextElementSibling.id);
  }

  summary.addEventListener('click', (event) => {
    event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
  });

  if (summary.closest('header-drawer')) return;
  summary.parentElement.addEventListener('keyup', onKeyUpEscape);
});

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

/*
 * Shopify Common JS
 *
 */
if ((typeof window.Shopify) == 'undefined') {
  window.Shopify = {};
}

Shopify.bind = function(fn, scope) {
  return function() {
    return fn.apply(scope, arguments);
  }
};

Shopify.setSelectorByValue = function(selector, value) {
  for (var i = 0, count = selector.options.length; i < count; i++) {
    var option = selector.options[i];
    if (value == option.value || value == option.innerHTML) {
      selector.selectedIndex = i;
      return i;
    }
  }
};

Shopify.addListener = function(target, eventName, callback) {
  target.addEventListener ? target.addEventListener(eventName, callback, false) : target.attachEvent('on'+eventName, callback);
};

Shopify.postLink = function(path, options) {
  options = options || {};
  var method = options['method'] || 'post';
  var params = options['parameters'] || {};

  var form = document.createElement("form");
  form.setAttribute("method", method);
  form.setAttribute("action", path);

  for(var key in params) {
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", key);
    hiddenField.setAttribute("value", params[key]);
    form.appendChild(hiddenField);
  }
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

Shopify.CountryProvinceSelector = function(country_domid, province_domid, options) {
  this.countryEl         = document.getElementById(country_domid);
  this.provinceEl        = document.getElementById(province_domid);
  this.provinceContainer = document.getElementById(options['hideElement'] || province_domid);

  Shopify.addListener(this.countryEl, 'change', Shopify.bind(this.countryHandler,this));

  this.initCountry();
  this.initProvince();
};

Shopify.CountryProvinceSelector.prototype = {
  initCountry: function() {
    var value = this.countryEl.getAttribute('data-default');
    Shopify.setSelectorByValue(this.countryEl, value);
    this.countryHandler();
  },

  initProvince: function() {
    var value = this.provinceEl.getAttribute('data-default');
    if (value && this.provinceEl.options.length > 0) {
      Shopify.setSelectorByValue(this.provinceEl, value);
    }
  },

  countryHandler: function(e) {
    var opt       = this.countryEl.options[this.countryEl.selectedIndex];
    var raw       = opt.getAttribute('data-provinces');
    var provinces = JSON.parse(raw);

    this.clearOptions(this.provinceEl);
    if (provinces && provinces.length == 0) {
      this.provinceContainer.style.display = 'none';
    } else {
      for (var i = 0; i < provinces.length; i++) {
        var opt = document.createElement('option');
        opt.value = provinces[i][0];
        opt.innerHTML = provinces[i][1];
        this.provinceEl.appendChild(opt);
      }

      this.provinceContainer.style.display = "";
    }
  },

  clearOptions: function(selector) {
    while (selector.firstChild) {
      selector.removeChild(selector.firstChild);
    }
  },

  setOptions: function(selector, values) {
    for (var i = 0, count = values.length; i < values.length; i++) {
      var opt = document.createElement('option');
      opt.value = values[i];
      opt.innerHTML = values[i];
      selector.appendChild(opt);
    }
  }
};

//variant change
  class DynamicProductCards extends HTMLElement {
    constructor() {
      super();

      let _this = this;
      this.variantDataScript = this.querySelector('[type="application/json"]');
      if(this.variantDataScript) {
        this.variantData = JSON.parse(this.variantDataScript.textContent);
        this.addEventListener('input', this.onVariantChange.bind(this));
      }

      if(this.querySelector('button[type="submit"]')) {
        this.querySelector('button[type="submit"]').addEventListener('click', function(event) {
          event.preventDefault();
          _this.addItem();
        });
      }    
    }

    onVariantChange() {
      let selectedOptions = [];
      this.querySelectorAll('input[type="radio"]').forEach(function(input) {
        if(input.checked) {
          selectedOptions.push(input.value);
        }
      })

      this.getCurrentVariant(selectedOptions);
    }

    getCurrentVariant(options) {
      let currentVariant = {};

      this.variantData.forEach(function(variant) {
        if(JSON.stringify(variant.options) == JSON.stringify(options)) {
          currentVariant = variant;
        }
      })

      this.updateMainId(currentVariant);
    }

    updateMainId(currentVariant) {
      this.querySelector('[name="id"]').value = currentVariant.id;

      this.getUpdatedCard(currentVariant);
    }

    getUpdatedCard(currentVariant) {
      this.sectionId = this.dataset.sectionId;
      this.productHandle = this.dataset.productHandle;

      fetch(`${this.productHandle}?variant=${currentVariant.id}&section_id=${this.sectionId}`)
      .then((response) => response.text())
      .then((responseText) => {
        const html = new DOMParser().parseFromString(responseText, 'text/html');     
        this.innerHTML = html.querySelector(`[data-product-handle="${this.productHandle}"]`).innerHTML;
      });
    }

    addItem() {
      let addToCartForm = this.querySelector('form[action$="/cart/add"]');
      let formData = new FormData(addToCartForm);
      
      fetch('/cart/add.js', {
        method: 'POST',
        body: formData
      })
      .then(response => {
        document.querySelector('wizaah-cart').refreshCart();
        document.querySelector('wizaah-cart').open();
      })
      .catch((error) => {
        console.error('Error:', error);
      });
    }
  }

  customElements.define('dynamic-product-cards', DynamicProductCards);


